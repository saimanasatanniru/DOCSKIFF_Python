from django.shortcuts import render
from django.urls import reverse_lazy
from . import forms
from django.views.generic import CreateView
from .models import *
from django.contrib.auth.mixins import LoginRequiredMixin
from UserApp.forms import ProductForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect

# Create your views here.
def welcome(request):
    return render(request,'welcome.html')

def profile(request):
    return render(request,'profile.html')

def products(request):
    productss = Product.objects.filter(user = request.user)
    return render(request, 'products.html', {'productss':productss})

class SignUp(CreateView):
    form_class = forms.UserCreateFrom
    success_url = reverse_lazy('login')
    template_name = 'signup.html'

@login_required
def CreateProductView(request):

    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = Product(
                productname = form.cleaned_data['productname'],
                price = form.cleaned_data['price'],
                discription = form.cleaned_data['discription'],
                user = User.objects.get(username__iexact=request.user.username),
            )
            product.save()
            return HttpResponseRedirect('/products/')
    else:
        form = ProductForm()

    return render(request,'product_form.html', {
        'form': form,
    })
