
import os
import unittest
from cast.analysers.test import UATestAnalysis

class Test(unittest.TestCase):

    def test_contact_details(self):
        print (os.getcwd())
        analysis = UATestAnalysis('ColdFusion')
        analysis.add_selection('Sample')
        analysis.set_verbose(True)
        analysis.run()

if __name__ == "__main__":
    unittest.main()

