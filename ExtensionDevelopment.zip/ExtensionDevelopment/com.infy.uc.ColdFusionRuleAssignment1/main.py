import os
import traceback


from cast.analysers import log
import cast.analysers.ua

from cast.analysers import create_link,CustomObject,Bookmark

class ColdFusion(cast.analysers.ua.Extension):
    
    def _init_(self):
        log.debug ('In __init__ ... ')
#          

    def start_analysis(self):
        log.debug ('In start_analysis ... ')
        
    
    def start_file(self, file):
        log.debug ('In start_file ... ' + str(file))
        self.file_obj = file
        self.file_path = self.file_obj.get_path()
        print("outside")
        
        if self.file_path.endswith('.cfc'):
            f=open(self.file_path,"r")
            line = f.readlines()
            print(line)
            for x in f:
                print(x.readline())
            cfc_comp = CustomObject()
            cfc_func = CustomObject()
            cfc_arg  = CustomObject()
            fileobj = CustomObject()
            for row1 in line:
                print(row1)
                if "<cfcomponent" in row1:
                    self.saveObject(cfc_comp,"cfcomponent",self.file_path,"cfcomponent",self.file_obj,self.file_path + "cfc_comp")
                if "<cffunction" in row1:
                    self.saveObject(cfc_func,"cffunction",self.file_path,"cffunction",self.file_obj,self.file_path + "cfc_func")
                    create_link('callLink',cfc_comp,cfc_func,Bookmark(self.file_obj,1,1,-1,-1))
                if "cfargument" in row1:
                    self.saveObject(cfc_arg,"cfargument",self.file_path,"cfargument",self.file_obj,self.file_path + "cfc_arg")
                    create_link('callLink',cfc_func,cfc_arg,Bookmark(self.file_obj,1,1,-1,-1))
            count=1
            for row in line:
                #log.debug(row)
                if(row.find('<CFCOMPONENT')!=-1):
                    log.debug("violation found at"+ str(count))                    
                    self.saveObject(fileobj,"cffileobj",self.file_path,"cffileobj",self.file_obj,self.file_path + "fileobj")			
                    fileobj.save_violation("COLDFUSION_naming.coldfusionname",Bookmark(file, count, 1, count, -1), additional_bookmarks=None)
                    log.debug("violation created")
                count+=1
                
    def saveObject(self, obj_refr, name, fullname, obj_type, parent, guid):
        obj_refr.set_name(name)
        log.debug('object name..'+name)
        obj_refr.set_fullname(fullname)
        obj_refr.set_type(obj_type)
        obj_refr.set_parent(parent)
        obj_refr.set_guid(guid) 
        obj_refr.save()        
