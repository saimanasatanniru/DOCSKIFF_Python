from django.db import models
from django.forms import ModelForm

# Create your models here.
class User(models.Model):
    first_name = models.CharField(max_length=128)
    last_name = models.CharField(max_length=128)
    email = models.EmailField(max_length=254,unique=True)

class UserForm(ModelForm):
    class Meta:
        model = User
        fields = ['first_name','last_name','email']
