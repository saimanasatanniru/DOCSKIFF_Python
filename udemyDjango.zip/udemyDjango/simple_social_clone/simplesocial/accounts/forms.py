from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm

class UserCreateFrom(UserCreationForm):

    class Meta:
        fields = ('username','email','password1','password2')#this comes from the UserCreationForm build in django utility
        model = get_user_model()

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['username'].label = 'Display Name'
        self.fields['email'].label = 'Email Address' #these labels are used to display them in the html page, by default the html page shows username , emial,...to change them we will keep a labels
